﻿


using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using System;

namespace ass4
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {

        string ItemFirst;
        SeekBar seekBar;
        float totalPriced;
        int selectedQuantity;
        int tip;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);


            var spinner = FindViewById<Spinner>(Resource.Id.spinner1);
            var quantityseekbar = FindViewById<EditText>(Resource.Id.quantity);

            var itemAdapter = ArrayAdapter.CreateFromResource(this, Resource.Array.item_array, Android.Resource.Layout.SimpleSpinnerItem);
            var totalPrice = FindViewById<EditText>(Resource.Id.price);


            Button save = FindViewById<Button>(Resource.Id.buttonSave);
            save.Click += ButtonClick;

            itemAdapter.SetDropDownViewResource(Android.Resource.Layout.SimpleSpinnerDropDownItem);
            spinner.Adapter = itemAdapter;
            ItemFirst = spinner.SelectedItem.ToString();
            spinner.ItemSelected += Spinner_ItemSelected;

            seekBar = FindViewById<SeekBar>(Resource.Id.numberSeekBar);
            seekBar.Progress = 1;
            seekBar.ProgressChanged += delegate
            {
                Toast.MakeText(this, $"No of items= {seekBar.Progress}", ToastLength.Long).Show();

                selectedQuantity = seekBar.Progress;
                quantityseekbar.Text = selectedQuantity.ToString();

                var item_price = FindViewById<EditText>(Resource.Id.price);



                if (tip<0)
                {
                    totalPrice.Text = (float.Parse(totalPrice.Text) * selectedQuantity + (float.Parse(totalPrice.Text) * selectedQuantity) * 13 / 100).ToString();
                   
                }
                else
                    totalPrice.Text = (float.Parse(totalPrice.Text) * selectedQuantity + ((float.Parse(totalPrice.Text) * selectedQuantity) * tip / 100) + ((float.Parse(totalPrice.Text) * selectedQuantity) * tip / 100) * 13 / 100).ToString();
                
            };


        }



        private void Spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            Spinner spinner = (Spinner)sender;
            int item = (int)spinner.SelectedItemId;
            var item_price = FindViewById<EditText>(Resource.Id.price);
            var imageView = FindViewById<ImageView>(Resource.Id.imageView1);

            if (item == 1)
            {
                item_price.Text = "3";
                imageView.SetImageResource(Resource.Drawable.porotta);

            }
            else if (item == 2)
            {
                item_price.Text = "7";
                imageView.SetImageResource(Resource.Drawable.curry);
            }
            else if (item == 3)
            {
                item_price.Text = "10";
                imageView.SetImageResource(Resource.Drawable.beef);
            }
            else if (item == 4)
            {
                item_price.Text = "12";
                imageView.SetImageResource(Resource.Drawable.pasta);
            }
            else if (item == 5)
            {
                item_price.Text = "15";
                imageView.SetImageResource(Resource.Drawable.pizza);
            }



        }


        private void RadioButtonClick(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            tip = Convert.ToInt16(rb.Text);

        }
        private void ButtonClick(object sender, EventArgs e)
        {
            Toast.MakeText(this, $"Your order is placed", ToastLength.Long).Show();
        }
    }
}


